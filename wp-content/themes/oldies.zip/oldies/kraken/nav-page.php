<?php

/* ======================================================================
	nav-page.php
	Template for older/newer page navigation.
 * ====================================================================== */

?>

<nav>
	<p><?php posts_nav_link( ' / ', __( '&larr; Newer', 'kraken' ), __( 'Older &rarr;', 'kraken' ) ); ?></p>
</nav>