<?php

/* ======================================================================
	nav-main.php
	Template for site navigation.

	You may wish to use `wp_nav_menu()` here.
	http://codex.wordpress.org/Function_Reference/wp_nav_menu

	Alternatively, you might hand-code your navigation
	or include a custom	function.
 * ====================================================================== */

?>