<?php

/* ======================================================================
	footer.php
	Template for footer content.
 * ====================================================================== */

?>

			<footer>

				<p><?php printf( __( 'Copyright &copy; %1$s %2$s. All rights reserved.', 'kraken' ), date( 'Y' ), get_bloginfo( 'name' ) ); ?></p>

			</footer>

		</section>

		<?php wp_footer(); ?>

	</body>
</html>