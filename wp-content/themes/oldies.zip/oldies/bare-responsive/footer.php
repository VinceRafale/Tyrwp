		<footer>
			<span>Free to edit and distribute as open source. Powered by <a href="http://wordpress.org/" rel="generator">Wordpress</a>.</span>. <a href="http://www.hongkiat.com/blog/wordpress-responsive-template/">Bare responsive theme</a> by <a href="http://www.hongkiat.com/blog/">Hongkiat.com</a>
<?php wp_footer(); ?>
</footer>
	</div>
</body>
</html>