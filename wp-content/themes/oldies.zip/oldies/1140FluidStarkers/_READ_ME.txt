
	STARKERS

	- - - - - - - - - - - - - - - - - - - - - - -

	Starkers is a bare-bones WordPress theme created 
	to act as a starting point for the theme designer.

	Free of all presentational elements and non-semantic 
	markup, Starkers is the perfect 'blank slate' for 
	your WordPress projects, as it's a stripped-back 
	version of the 'Twenty Ten' theme (versions prior to 
	3.0 were based on the now-retired 'Default' theme).

	Best of all: it's free and fully GPL-licensed, 
	so you can use it for whatever you like — even 
	your commercial projects.

	For full details, and for instructions, please see:
	http://starkerstheme.com/

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 3.0, updated 21.06.2010

	Re-built entirely from the ground up, using
	the new 'Twenty Ten' theme as its base

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.5, updated 11.11.2009

	Changed brand-wide typeface to FS Clerkenwell

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.2, revision 1, updated 23.07.2009

	Corrected: closing </div> tag in comments.php on line 87

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.2 for WP2.8.2, updated 21.07.2009

	Removed: Extra '>' in comments.php on line 50
	Changed: Commented out 'div, ul, li { position:relative }' in layout.css
	Added: GPL License included as '_LICENSE.txt'
	Renamed: 'READ_ME.txt' becomes '_READ_ME.txt'

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.8.1 for WP2.8.1, updated 12.07.2009

	Re-written from scratch, using the 'Default'
	theme included with WordPress 2.8 as a basis.

	- - - - - - - - - - - - - - - - - - - - - - -
	
	Versions 2.3 - 2.7

	Non-existent. Starkers is now named according to 
	the version of WordPress with which it is compatible.

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.2 for WP2.6.2, updated 02.11.2008

	Fixed: prev / next links typo in archive.php & index.php
	Fixed: closing </p> tag in comments.php

	- - - - - - - - - - - - - - - - - - - - - - -

	Version 2.1 for WP2.6.2, updated 29.09.2008

	Added: WP image-alignment and caption CSS
	Added: Page listing
	Removed: _comments-popup.php
	Fixed: prev / next links typo
	Fixed: duplicate 'h5' typo in reset.css

	- - - - - - - - - - - - - - - - - - - - - - -

	Enjoy!

	~ Elliot Jay Stocks
